import { Router } from "express";
import { createCategory } from "./app/useCases/createCategory";
import { listCategories } from "./app/useCases/listCategories";
export const router = Router();

router.get("/categories",listCategories);
//Rota create Category
router.post("/categories", createCategory);